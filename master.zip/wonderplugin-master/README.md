# Wonderplugin For RCE

### DONT USE THIS FAKE PLUGIN ON YOUR PRODUCTION WEB SERVER!
This repository purposed for test a vulnerability on wonderCMS, this fake plugin contain backdoor web shell, you can find it on evil.php file.

### Related Article 
[WonderCMS 3.1.3 - Authenticated RCE & Blind SSRF Vulnerability](https://zetc0de.github.io/post/authenticated-rce-ssrf-wondercms/)

### Exploit-DB 
[WonderCMS 3.1.3 - Authenticated Remote Code Execution](https://www.exploit-db.com/exploits/49155)

![NgSEC](preview.jpg)
